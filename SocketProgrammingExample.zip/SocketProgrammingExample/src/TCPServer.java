import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.*;
import java.net.*;

public class TCPServer {

	public static void main(String argv[]) throws Exception {

		String clientSentence;
		String similarWords = "";
		ArrayList<String> words = listMaker();
		System.out.println(words.size());
		ServerSocket welcomeSocket = new ServerSocket(6789);
		System.out.println("Server listening on port 6789");
		
		while(true) {
			
			Socket connectionSocket = welcomeSocket.accept();
			
			BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
		
			DataOutputStream outToClient = new DataOutputStream(connectionSocket.getOutputStream());
			
			try {
			while (true) {
			clientSentence = inFromClient.readLine();
			System.out.println(clientSentence);		
			for(String w : words) {
				if (w.toLowerCase().startsWith(clientSentence.toLowerCase())) {
					similarWords += w + ", ";
				}
				
			}
			System.out.println(similarWords.length());

			similarWords.trim();
			similarWords = similarWords.substring(0, similarWords.length() -2);
			System.out.println(similarWords.length());

			outToClient.writeBytes(similarWords + "\n");
			
			similarWords = "";
			}
		} catch (Exception e)  {
			//TODO: handle the particular possible exception for socket programming
			
			System.out.println("Client closed connection!");
		}
		
		
	}

}

	private static ArrayList<String> listMaker() {
		ArrayList<String> list = new ArrayList<String>();
		try {
		Scanner fileScanner = new Scanner(new File("words.txt"));
		while (fileScanner.hasNext()) {
			String currWord = fileScanner.nextLine();
			list.add(currWord);
		}
	} catch (Exception e){
		System.out.println("File Not Found");
		System.exit(0);
	}
		return list;
	}
}
