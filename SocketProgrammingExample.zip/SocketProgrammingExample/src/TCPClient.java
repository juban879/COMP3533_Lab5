import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.*;
import java.io.*;

public class TCPClient {
	
	public static void main(String argv[]) throws Exception {
		
		String sentence; 
		String modifiedSentence;
		
		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
		
		Socket clientSocket = new Socket("localhost", 6789);
		System.out.println("Successfully accepeted a connection from client with the following IP and Port: " + clientSocket.getInetAddress() + ":" + clientSocket.getPort());
		
		DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
	
		BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
		
		System.out.println("Please enter a word to search");
		
		sentence = inFromUser.readLine();
		System.out.println(sentence);
		while (sentence.toLowerCase().compareTo("exit") !=0 ) {
			outToServer.writeBytes(sentence + '\n');
			
			modifiedSentence = inFromServer.readLine();
			
			System.out.println("The following words start with " + sentence + ": " + modifiedSentence);
			System.out.println("Please enter a word to search");
			sentence = inFromUser.readLine();
		}
		
		clientSocket.close();
	}

} 
